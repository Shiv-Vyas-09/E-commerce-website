let cart = JSON.parse(localStorage.getItem("cart")) || []

function saveCart() {
  localStorage.setItem("cart", JSON.stringify(cart))
}

function addToCart(product) {
  const existingItem = cart.find((item) => item.id === product.id)
  if (existingItem) {
    existingItem.quantity++
  } else {
    cart.push({ ...product, quantity: 1 })
  }
  saveCart()
  updateCartDisplay()
  showCartNotification(product)
}

function showCartNotification(product) {
  const notification = document.getElementById("cart-notification")
  const notificationImage = document.getElementById("cart-notification-image")
  notificationImage.src = product.image
  notification.style.display = "flex"
  setTimeout(() => {
    notification.style.display = "none"
  }, 3000)
}

function removeFromCart(id) {
  cart = cart.filter((item) => item.id !== id)
  saveCart()
  updateCartDisplay()
}

function updateQuantity(id, change) {
  const item = cart.find((item) => item.id === id)
  if (item) {
    item.quantity = Math.max(1, item.quantity + change)
    saveCart()
    updateCartDisplay()
  }
}

function updateCartDisplay() {
  const cartItemsElement = document.getElementById("cart-items")
  if (cartItemsElement) {
    cartItemsElement.innerHTML = ""

    cart.forEach((item) => {
      const row = document.createElement("tr")
      row.className = "tbody-item"
      row.innerHTML = `
                <td class="product-remove">
                    <a class="remove" href="javascript:void(0)" onclick="removeFromCart(${item.id})">×</a>
                </td>
                <td class="product-thumbnail">
                    <div class="thumb">
                        <a href="single-product.html">
                            <img src="${item.image}" width="68" height="84" alt="Image-HasTech">
                        </a>
                    </div>
                </td>
                <td class="product-name">
                    <a class="title" href="single-product.html">${item.name}</a>
                </td>
                <td class="product-price">
                    <span class="price">$${item.price.toFixed(2)}</span>
                </td>
                <td class="product-quantity">
                    <div class="pro-qty">
                        <button onclick="updateQuantity(${item.id}, -1)">-</button>
                        <span>${item.quantity}</span>
                        <button onclick="updateQuantity(${item.id}, 1)">+</button>
                    </div>
                </td>
                <td class="product-subtotal">
                    <span class="price">$${(item.price * item.quantity).toFixed(2)}</span>
                </td>
            `
      cartItemsElement.appendChild(row)
    })
  }

  updateTotals()
  updateMiniCart()
}

function updateTotals() {
  const subtotal = cart.reduce((total, item) => total + item.price * item.quantity, 0)
  const shippingCost = Number.parseFloat(document.querySelector('input[name="shipping"]:checked')?.value || 0)
  const total = subtotal + shippingCost

  const subtotalElement = document.getElementById("subtotal")
  const totalElement = document.getElementById("total")

  if (subtotalElement) subtotalElement.textContent = `$${subtotal.toFixed(2)}`
  if (totalElement) totalElement.textContent = `$${total.toFixed(2)}`
}

function updateMiniCart() {
  const miniCartElement = document.querySelector(".aside-cart-product-list")
  const miniCartTotalElement = document.querySelector(".cart-total .amount")

  if (miniCartElement && miniCartTotalElement) {
    miniCartElement.innerHTML = ""
    let total = 0

    cart.forEach((item) => {
      const li = document.createElement("li")
      li.className = "aside-product-list-item"
      li.innerHTML = `
                <a href="#/" class="remove" onclick="removeFromCart(${item.id})">×</a>
                <a href="product-details.html">
                    <img src="${item.image}" width="68" height="84" alt="Image">
                    <span class="product-title">${item.name}</span>
                </a>
                <span class="product-price">${item.quantity} × $${item.price.toFixed(2)}</span>
            `
      miniCartElement.appendChild(li)
      total += item.price * item.quantity
    })

    miniCartTotalElement.textContent = `$${total.toFixed(2)}`
  }
}

document.addEventListener("DOMContentLoaded", () => {
  updateCartDisplay()
})

// Initial update
updateCartDisplay()

